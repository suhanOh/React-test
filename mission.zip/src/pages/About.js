import React from "react";

const About = () =>{
    return<h1>About 화면 입니다.</h1>
}

export default About;